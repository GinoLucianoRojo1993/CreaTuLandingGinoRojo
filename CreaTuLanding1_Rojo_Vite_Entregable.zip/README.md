# CreaTuLanding (Vite + React)

Este proyecto fue generado con **Vite + React** y contiene la estructura completa para poder instalar dependencias y ejecutarlo.

## Requisitos
- Node.js 18+ (recomendado)

## Instalación
```bash
npm install
```

## Ejecutar en modo desarrollo
```bash
npm run dev
```

## Build de producción
```bash
npm run build
npm run preview
```

## Estructura
- `index.html` (entrada)
- `vite.config.js` (config de Vite)
- `public/` (assets estáticos)
- `src/` (componentes y estilos)
