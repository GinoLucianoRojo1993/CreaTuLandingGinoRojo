const CartWidget = () => {
  const itemsInCart = 0;

  return (
    <button className="cart-widget">
      <span className="cart-widget__icon" role="img" aria-label="Carrito">
        🛒
      </span>
      <span className="cart-widget__count">{itemsInCart}</span>
    </button>
  );
};

export default CartWidget;
