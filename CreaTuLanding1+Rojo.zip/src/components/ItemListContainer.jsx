const ItemListContainer = ({ greeting }) => {
  return (
    <main className="item-list-container">
      <h2 className="item-list-container__title">{greeting}</h2>
      <p className="item-list-container__subtitle">
        Muy pronto vas a poder ver el catálogo de productos en esta sección.
      </p>
    </main>
  );
};

export default ItemListContainer;
